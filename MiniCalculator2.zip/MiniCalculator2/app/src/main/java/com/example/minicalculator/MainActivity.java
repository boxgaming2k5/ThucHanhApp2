package com.example.minicalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtNumber1, edtNumber2;
    TextView txtResult;
    Button btnAdd, btnSub, btnMul, btnDiv, btnClearHistory;
    RecyclerView recyclerHistory;
    ArrayList<String> historyList = new ArrayList<>();
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNumber1 = findViewById(R.id.edtNumber1);
        edtNumber2 = findViewById(R.id.edtNumber2);
        txtResult = findViewById(R.id.txtResult);
        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        btnClearHistory = findViewById(R.id.btnClearHistory);
        recyclerHistory = findViewById(R.id.recyclerHistory);

        adapter = new HistoryAdapter(historyList);
        recyclerHistory.setLayoutManager(new LinearLayoutManager(this));
        recyclerHistory.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> calculate('+'));
        btnSub.setOnClickListener(v -> calculate('-'));
        btnMul.setOnClickListener(v -> calculate('*'));
        btnDiv.setOnClickListener(v -> calculate('/'));

        btnClearHistory.setOnClickListener(v -> {
            historyList.clear();
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Đã xóa lịch sử", Toast.LENGTH_SHORT).show();
        });
    }

    private void calculate(char op) {
        String s1 = edtNumber1.getText().toString().trim();
        String s2 = edtNumber2.getText().toString().trim();

        if (s1.isEmpty() || s2.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đủ hai số!", Toast.LENGTH_SHORT).show();
            return;
        }

        double a = Double.parseDouble(s1);
        double b = Double.parseDouble(s2);
        double result = 0;
        String expression;

        switch (op) {
            case '+': result = a + b; break;
            case '-': result = a - b; break;
            case '*': result = a * b; break;
            case '/':
                if (b == 0) {
                    Toast.makeText(this, "Không thể chia cho 0!", Toast.LENGTH_SHORT).show();
                    return;
                }
                result = a / b;
                break;
        }

        expression = a + " " + op + " " + b + " = " + result;
        txtResult.setText("Kết quả: " + result);
        historyList.add(0, expression); // thêm lên đầu
        adapter.notifyItemInserted(0);
        recyclerHistory.scrollToPosition(0);
    }
}
