package com.example.happy2010;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnGreeting, btnCards;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGreeting = findViewById(R.id.btnGreeting);
        btnCards = findViewById(R.id.btnCards);

        btnGreeting.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, GreetingActivity.class);
            startActivity(intent);
        });

        btnCards.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CardActivity.class);
            startActivity(intent);
        });
    }
}
