package com.example.happy2010;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.app.Dialog;

public class CardActivity extends AppCompatActivity {
    GridView gridView;
    int[] cardImages = {
            R.drawable.card1, R.drawable.card2, R.drawable.card3,
            R.drawable.card4, R.drawable.card5, R.drawable.card6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        gridView = findViewById(R.id.gridCards);
        gridView.setAdapter(new CardAdapter(this, cardImages));

        gridView.setOnItemClickListener((AdapterView<?> parent, android.view.View view, int position, long id) -> {
            Dialog dialog = new Dialog(CardActivity.this);
            dialog.setContentView(R.layout.dialog_card);
            ImageView img = dialog.findViewById(R.id.imgCardLarge);
            img.setImageResource(cardImages[position]);
            dialog.show();
        });
    }
}
