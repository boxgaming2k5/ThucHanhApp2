package com.example.happy2010;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class CardAdapter extends BaseAdapter {
    private Context context;
    private int[] cardImages;

    public CardAdapter(Context context, int[] cardImages) {
        this.context = context;
        this.cardImages = cardImages;
    }

    @Override
    public int getCount() {
        return cardImages.length;
    }

    @Override
    public Object getItem(int position) {
        return cardImages[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView image = new ImageView(context);
        image.setImageResource(cardImages[position]);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setLayoutParams(new ViewGroup.LayoutParams(400, 400));
        return image;
    }
}
