package com.example.happy2010;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GreetingActivity extends AppCompatActivity {
    EditText edtName, edtMessage;
    Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_greeting);

        edtName = findViewById(R.id.edtName);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(v -> {
            String name = edtName.getText().toString().trim();
            String msg = edtMessage.getText().toString().trim();

            if (name.isEmpty() || msg.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
            } else {
                String fullMsg = "💖 Gửi đến " + name + ": " + msg;
                Toast.makeText(this, fullMsg, Toast.LENGTH_LONG).show();
            }
        });
    }
}
