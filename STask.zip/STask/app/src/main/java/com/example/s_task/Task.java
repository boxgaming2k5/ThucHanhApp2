package com.example.stask; // Thay bằng package của bạn

import java.io.Serializable;

// Implement Serializable để truyền đối tượng qua Intent
public class Task implements Serializable {
    private long id;
    private String title;
    private String description;
    private long dueDate; // Lưu dạng timestamp (milliseconds)
    // (Bạn có thể thêm trường boolean isCompleted cho phần mở rộng)

    public Task(long id, String title, String description, long dueDate) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
    }

    // Thêm đầy đủ Getters và Setters
    public long getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public long getDueDate() { return dueDate; }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setDueDate(long dueDate) { this.dueDate = dueDate; }
}