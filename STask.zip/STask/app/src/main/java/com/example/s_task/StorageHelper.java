package com.example.stask; // Thay bằng package của bạn

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class StorageHelper {
    private static final String PREFS_NAME = "STaskPrefs";
    private static final String TASKS_KEY = "TasksList";
    private static Gson gson = new Gson();

    public static void saveTasks(Context context, List<Task> tasks) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        String jsonTasks = gson.toJson(tasks);
        editor.putString(TASKS_KEY, jsonTasks);
        editor.apply();
    }

    public static ArrayList<Task> loadTasks(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String jsonTasks = prefs.getString(TASKS_KEY, null);

        if (jsonTasks == null) {
            return new ArrayList<>(); // Trả về danh sách rỗng
        }

        Type type = new TypeToken<ArrayList<Task>>() {}.getType();
        return gson.fromJson(jsonTasks, type);
    }
}