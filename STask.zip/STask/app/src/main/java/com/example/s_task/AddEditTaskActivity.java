package com.example.stask; // Thay bằng package của bạn

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddEditTaskActivity extends AppCompatActivity {

    private EditText etTitle, etDescription;
    private Button btnPickDate, btnSave;
    private TextView tvSelectedDate;

    private Calendar selectedDateTime = Calendar.getInstance();
    private boolean isEditMode = false;
    private Task existingTask;
    private int taskPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_task);

        etTitle = findViewById(R.id.editTextTaskTitle);
        etDescription = findViewById(R.id.editTextTaskDescription);
        btnPickDate = findViewById(R.id.buttonPickDueDate);
        btnSave = findViewById(R.id.buttonSaveTask);
        tvSelectedDate = findViewById(R.id.textViewSelectedDate);

        // Kiểm tra xem đây là Thêm mới hay Chỉnh sửa
        if (getIntent().hasExtra("TASK")) {
            isEditMode = true;
            existingTask = (Task) getIntent().getSerializableExtra("TASK");
            taskPosition = getIntent().getIntExtra("POSITION", -1);

            setTitle("Sửa công việc");
            etTitle.setText(existingTask.getTitle());
            etDescription.setText(existingTask.getDescription());
            selectedDateTime.setTimeInMillis(existingTask.getDueDate());
        } else {
            isEditMode = false;
            setTitle("Thêm công việc mới");
            // Để ngày giờ mặc định là 1 tiếng sau
            selectedDateTime.add(Calendar.HOUR_OF_DAY, 1);
        }

        updateDateLabel(); // Cập nhật text ngày giờ

        btnPickDate.setOnClickListener(v -> showDateTimePicker());
        btnSave.setOnClickListener(v -> saveTask());
    }

    private void showDateTimePicker() {
        Calendar currentDate = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedDateTime.set(Calendar.YEAR, year);
            selectedDateTime.set(Calendar.MONTH, month);
            selectedDateTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            // Hiển thị chọn giờ ngay sau khi chọn ngày
            new TimePickerDialog(this, (timeView, hourOfDay, minute) -> {
                selectedDateTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selectedDateTime.set(Calendar.MINUTE, minute);
                selectedDateTime.set(Calendar.SECOND, 0); // Đặt giây = 0
                updateDateLabel();
            }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), true).show();

        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updateDateLabel() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        tvSelectedDate.setText(sdf.format(selectedDateTime.getTime()));
    }

    private void saveTask() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        long dueDate = selectedDateTime.getTimeInMillis();

        if (TextUtils.isEmpty(title)) {
            Toast.makeText(this, "Vui lòng nhập tên công việc", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dueDate <= System.currentTimeMillis()) {
            Toast.makeText(this, "Vui lòng chọn ngày hết hạn trong tương lai", Toast.LENGTH_SHORT).show();
            return;
        }

        Task taskToSave;
        if (isEditMode) {
            existingTask.setTitle(title);
            existingTask.setDescription(description);
            existingTask.setDueDate(dueDate);
            taskToSave = existingTask;
        } else {
            long newId = System.currentTimeMillis(); // Dùng timestamp làm ID duy nhất
            taskToSave = new Task(newId, title, description, dueDate);
        }

        // Đóng gói dữ liệu và trả về MainActivity
        Intent resultIntent = new Intent();
        resultIntent.putExtra("TASK", taskToSave);
        if (isEditMode) {
            resultIntent.putExtra("POSITION", taskPosition);
        }

        setResult(RESULT_OK, resultIntent);
        Toast.makeText(this, "Đã lưu công việc!", Toast.LENGTH_SHORT).show();
        finish(); // Đóng Activity này
    }
}