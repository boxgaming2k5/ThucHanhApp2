package com.example.stask; // Thay bằng package của bạn

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String CHANNEL_ID = "STASK_CHANNEL_ID";
    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private ArrayList<Task> taskList;
    private FloatingActionButton fab;

    private ActivityResultLauncher<Intent> taskLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 0. Tạo Notification Channel (quan trọng cho Android 8+)
        createNotificationChannel();

        // 1. Ánh xạ
        recyclerView = findViewById(R.id.recyclerViewTasks);
        fab = findViewById(R.id.fabAddTask);

        // 2. Tải dữ liệu
        taskList = StorageHelper.loadTasks(this);

        // 3. Setup RecyclerView
        setupRecyclerView();

        // 4. Sự kiện nút "+" (FAB)
        fab.setOnClickListener(v -> openAddTaskScreen());

        // 5. Đăng ký ActivityResultLauncher để nhận kết quả
        // Đây là cách làm mới (thay cho onActivityResult)
        taskLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.hasExtra("TASK")) {
                            Task receivedTask = (Task) data.getSerializableExtra("TASK");
                            int position = data.getIntExtra("POSITION", -1);

                            if (position == -1) { // Thêm mới
                                taskList.add(receivedTask);
                            } else { // Cập nhật (Sửa)
                                cancelTaskAlarm(taskList.get(position)); // Hủy alarm cũ
                                taskList.set(position, receivedTask);
                            }

                            adapter.notifyDataSetChanged();
                            StorageHelper.saveTasks(this, taskList);
                            setTaskAlarm(receivedTask); // Đặt (hoặc đặt lại) alarm
                        }
                    }
                }
        );
    }

    private void openAddTaskScreen() {
        Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
        intent.putExtra("ACTION", "ADD");
        taskLauncher.launch(intent);
    }

    private void setupRecyclerView() {
        adapter = new TaskAdapter(this, taskList, new TaskAdapter.OnTaskClickListener() {
            @Override
            public void onTaskClick(int position) {
                // Mở màn hình Sửa
                Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
                intent.putExtra("ACTION", "EDIT");
                intent.putExtra("TASK", taskList.get(position));
                intent.putExtra("POSITION", position);
                taskLauncher.launch(intent);
            }

            @Override
            public void onTaskLongClick(int position) {
                // Xử lý Xóa 1 công việc
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Xóa công việc")
                        .setMessage("Bạn có chắc muốn xóa công việc này?")
                        .setPositiveButton("Xóa", (dialog, which) -> {
                            Task taskToRemove = taskList.get(position);
                            cancelTaskAlarm(taskToRemove); // Hủy alarm trước
                            taskList.remove(position);
                            adapter.notifyItemRemoved(position);
                            StorageHelper.saveTasks(MainActivity.this, taskList);
                            Toast.makeText(MainActivity.this, "Đã xóa", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Hủy", null)
                        .show();
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    // 6. Setup Menu (nạp file main_menu.xml)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_add) {
            openAddTaskScreen();
            return true;
        } else if (id == R.id.menu_delete_all) {
            // Xử lý Xóa tất cả
            new AlertDialog.Builder(this)
                    .setTitle("Xóa tất cả")
                    .setMessage("Bạn có chắc muốn xóa TOÀN BỘ công việc?")
                    .setPositiveButton("Xóa", (dialog, which) -> {
                        for(Task task : taskList) {
                            cancelTaskAlarm(task); // Hủy tất cả alarms
                        }
                        taskList.clear();
                        adapter.notifyDataSetChanged();
                        StorageHelper.saveTasks(this, taskList);
                        Toast.makeText(this, "Đã xóa tất cả", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Hủy", null)
                    .show();
            return true;
        } else if (id == R.id.menu_about) {
            // Mở màn hình Giới thiệu
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // 7. Xử lý Alarm
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "STaskChannel";
            String description = "Kênh cho thông báo công việc S-Task";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void setTaskAlarm(Task task) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, TaskAlarmReceiver.class);
        intent.putExtra("TASK_TITLE", task.getTitle());
        intent.putExtra("TASK_DESC", task.getDescription());
        int pendingIntentId = (int) task.getId();
        intent.putExtra("TASK_ID", pendingIntentId);

        // FLAG_IMMUTABLE là bắt buộc cho Android 12+
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                pendingIntentId, // Request code phải DUY NHẤT
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Kiểm tra quyền (bỏ qua phần xin quyền phức tạp trong bài này)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, task.getDueDate(), pendingIntent);
            } else {
                Toast.makeText(this, "Cần cấp quyền Đặt báo thức chính xác", Toast.LENGTH_LONG).show();
                // Hướng dẫn người dùng:
                // startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));
            }
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, task.getDueDate(), pendingIntent);
        }
    }

    private void cancelTaskAlarm(Task task) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, TaskAlarmReceiver.class);
        int pendingIntentId = (int) task.getId();

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                pendingIntentId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
    }
}